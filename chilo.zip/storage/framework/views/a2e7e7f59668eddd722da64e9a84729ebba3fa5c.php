Hola <strong><?php echo e($name); ?></strong>,

<p>Descripcion <?php echo e($body); ?></p>
