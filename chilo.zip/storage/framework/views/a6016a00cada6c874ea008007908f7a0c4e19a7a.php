<?php $__env->startSection('content'); ?>
<div class="container">
  <div class="row justify-content-center">
      <div class="col-md-8">
        <div class="card">
          <header class="card-header text-center">
            <h4>Crear nueva sucursal</h4>
          </header>

          <div class="card-body">
            <?php echo $__env->make('facilities.error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php echo $__env->make('facilities.form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
          </div>
        </div>
      </div>
    </div>
</div>
<?php echo $__env->make('facilities.pw', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>