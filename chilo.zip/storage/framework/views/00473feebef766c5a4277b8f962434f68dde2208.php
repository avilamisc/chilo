<div class="row">
  <div class="col">
    <div class="text-center">
      <?php echo Form::label('subtitle', 'Por favor, responda a continuación:'); ?>

    </div>
  </div>
</div>

<?php echo Form::open(['route' => 'encuesta.store','method' => 'POST', 'class' => 'app-form']); ?>

<?php $__currentLoopData = $survey->getQuestions(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div class="form-row">
    <div class="col">
        <?php echo Form::label('description', $question->description); ?>

        <?php if($question->control == 1): ?>
          <?php echo $__env->make('surveys.controls.open', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php elseif($question->control == 2): ?>
          <?php echo $__env->make('surveys.controls.emoticons', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php elseif($question->control == 3): ?>
          <?php echo $__env->make('surveys.controls.rating', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php elseif($question->control == 4): ?>
          <?php echo $__env->make('surveys.controls.radiobutton', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php else: ?>
          <?php echo $__env->make('surveys.controls.open', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php endif; ?>
    </div>
  </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<div class="row">
  <div class="col">
    <?php echo Form::label('customername', 'Nombre'); ?>

    <?php echo Form::text('customername', '',['class' => 'form-control', 'placeholder' => 'Primer Nombre'] ); ?>

  </div>
  <div class="col">
    <?php echo Form::label('customeremail', 'Correo Electronico'); ?>

    <?php echo Form::text('customeremail', '',['class' => 'form-control', 'placeholder' => 'correo@correo.com'] ); ?>

  </div>
  <div class="col">
    <?php echo Form::label('birthdate', 'Fecha Cumpleaños'); ?>

    <?php echo Form::date('birthdate', \Carbon\Carbon::now()); ?>

  </div>
</div>
<div class="float-right">
    <input type="submit" value="Enviar" class="btn btn-success">
</div>
<?php echo e(Form::hidden('ticket', '', ['id' => 'ticketID'])); ?>

<?php echo Form::close(); ?>

