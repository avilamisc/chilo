<?php $__env->startSection('content'); ?>
<div class="container">
  <div class="card padding">
    <header>
      <h4>Nuevo rol</h4>
    </header>

    <div class="card-body">
      <?php echo $__env->make('roles.error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <?php echo Form::open(['route' => 'roles.store' , 'class' => 'app-form']); ?>

        <?php echo $__env->make('roles.form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <?php echo Form::close(); ?>

    </div>
  </div>
</div>
<?php echo $__env->make('roles.pw', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>