<?php $__env->startSection('content'); ?>
  <div class="container">
    <div class="card padding">
      <header class="text-center">
        <div class="row">
          <div class="col">
              <h4>Listado de Roles</h4>
          </div>
          <div class="col">
            <div class="float-right">
              <?php if (\Shinobi::can('roles.create')): ?>
              <?php echo Form::open(['route' => ['roles.create'],
                'method' => 'GET']); ?>

                <button type="submit" class="btn btn-success">
                  <span class="fas fa-plus-square"></span>
                  Nuevo
                </button>
              <?php echo Form::close(); ?>

              <?php endif; ?>
            </div>
          </div>
        </div>
      </header>
      <div class="card-body text-center">
        <table class="table table-hover">
          <thead>
            <tr>
              <th scope="col">Nombre</th>
              <th scope="col">Descripcion</th>
              <?php if (\Shinobi::can('roles.edit')): ?>
              <th scope="col">Editar</th>
              <?php endif; ?>
              <?php if (\Shinobi::can('roles.destroy')): ?>
              <th scope="col">Eliminar</th>
              <?php endif; ?>
            </tr>
          </thead>
          <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><?php echo e($role->name); ?></td>
              <td><?php echo e($role->description); ?></td>
              <?php if (\Shinobi::can('roles.edit')): ?>
                <td class="text-center">
                  <?php echo Form::open(['route' => ['roles.edit',$role->id],
                    'method' => 'GET']); ?>

                    <button type="submit" class="btn btn-primary">
                      <span id="sEdit" class="fas fa-edit"></span>
                    </button>
                  <?php echo Form::close(); ?>

                </td>
              <?php endif; ?>
              <?php if (\Shinobi::can('roles.destroy')): ?>
                <td class="text-center">
                  <?php echo Form::open(['route' => ['roles.destroy',$role->id],
                    'method' => 'DELETE',
                    'onsubmit' => 'return confirm("¿Estás seguro de eliminar este rol?")']); ?>

                  <button type="submit" class="btn btn-danger">
                      <i class="fas fa-trash-alt"></i>
                    </button>
                  <?php echo Form::close(); ?>

                </td>
              <?php endif; ?>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
      </div>
    </div>
    <div class="actions text-center">
      <?php echo e($roles->links()); ?>

    </div>
  </div>
  <?php echo $__env->make('roles.pw', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>