<?php $__env->startSection('content'); ?>
  <div class="container">
    <div class="card padding">
      <header class="text-center">
        <div class="row">
          <div class="col">
              <h4>Listado de Usuarios</h4>
          </div>
        </div>
      </header>
      <div class="card-body text-center">
        <table class="table table-hover">
          <thead>
            <tr>
              <th scope="col">Nombre</th>
              <th scope="col">Correo</th>
              <?php if (\Shinobi::can('usuarios.edit')): ?>
              <th scope="col">Editar</th>
              <?php endif; ?>
              <?php if (\Shinobi::can('usuarios.destroy')): ?>
              <th scope="col">Eliminar</th>
              <?php endif; ?>
            </tr>
          </thead>
          <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><?php echo e($user->name); ?></td>
              <td><?php echo e($user->email); ?></td>
              <?php if (\Shinobi::can('usuarios.edit')): ?>
                <td class="text-center">
                  <?php echo Form::open(['route' => ['usuarios.edit',$user->id],
                    'method' => 'GET']); ?>

                    <button type="submit" class="btn btn-primary">
                      <span id="sEdit" class="fas fa-edit"></span>
                    </button>
                  <?php echo Form::close(); ?>

                </td>
              <?php endif; ?>
              <?php if (\Shinobi::can('usuarios.destroy')): ?>
                <td class="text-center">
                  <?php echo Form::open(['route' => ['usuarios.destroy',$user->id],
                    'method' => 'DELETE',
                    'onsubmit' => 'return confirm("¿Estás seguro de eliminar este usuario?")']); ?>

                  <button type="submit" class="btn btn-danger">
                      <i class="fas fa-trash-alt"></i>
                    </button>
                  <?php echo Form::close(); ?>

                </td>
              <?php endif; ?>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
      </div>
    </div>
    <div class="actions text-center">
      <?php echo e($users->links()); ?>

    </div>
  </div>
  <?php echo $__env->make('users.pw', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>