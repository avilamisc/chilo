  <div class="form-row">
    <div class="col-1">
      <div class="">
        <?php echo Form::label('id', 'Id Sistema'); ?>

        <?php echo Form::text('id', $role->id,['class' => 'form-control', 'readonly' => 'true'] ); ?>

      </div>
    </div>
    <div class="col">
      <div class="">
        <?php echo Form::label('name', 'Nombre'); ?>

        <?php echo Form::text('name', $role->name,['class' => 'form-control'] ); ?>

      </div>
    </div>
    <div class="col">
      <div class="">
        <?php echo Form::label('description', 'Descripción'); ?>

        <?php echo Form::text('description', $role->description,['class' => 'form-control'] ); ?>

      </div>
    </div>
    <div class="col">
      <div class="">
        <?php echo Form::label('slug', 'URL Amigable'); ?>

        <?php echo Form::text('slug', $role->slug,['class' => 'form-control'] ); ?>

      </div>
    </div>
  </div>
  <hr>
  <h3>Permiso Especial</h3>
  <div class="form-group">
    <label><?php echo e(Form::radio('special','all-access')); ?> Acceso Total</label>
    <label><?php echo e(Form::radio('special','no-access')); ?>  Ningún Acceso</label>
  </div>
  <hr>
  <div class="row">
    <div class="col">
      <h3>Lista de Permisos</h3>
      <div class="form-group">
      </div>
      <ul class="list-unstyled">
        <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php
          $checked = false;

          foreach ($currentPerms as $asignedPerm) {            
            if ($permission->id == (int)$asignedPerm) {
                $checked = true;
                continue;
            }
          }

          ?>
          <li>
            <label>
              <?php echo e(Form::checkbox('permissions[]', $permission->id, $checked)); ?>

              <?php echo e($permission->name); ?>

              <em>(<?php echo e($permission->description); ?>)</em>
            </label>
          </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      </ul>
    </div>
  </div>
<div class="form-row">
  <div class="col">
    <div class="float-right">
      <input type="submit" value="Guardar" class="btn btn-primary">
    </div>
  </div>
</div>
