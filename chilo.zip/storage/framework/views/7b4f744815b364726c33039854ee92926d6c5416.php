<?php echo Form::open(['route' => [$facility->url(),$facility->id],'method' => $facility->method(), 'class' => 'app-form']); ?>

  <div class="form-row">
    <div class="col-2">
      <?php echo Form::label('id', 'Id Sistema'); ?>

      <?php echo Form::text('id', $facility->id,['class' => 'form-control shortText', 'readonly' => 'true'] ); ?>

    </div>
    <div class="col-4">
      <?php echo Form::label('type', 'Tipo'); ?>

      <?php echo Form::select('type', $facility->fTypes(), $facility->type, ['class' => 'form-control']); ?>

    </div>
    <div class="col-6">
      <?php echo Form::label('name', 'Nombre'); ?>

      <?php echo Form::text('name',$facility->name,['class' => 'form-control', 'placeholder' => 'Nombre'] ); ?>

    </div>
  </div>
  <div class="form-row">
    <div class="col">
      <?php echo Form::label('address', 'Direccion'); ?>

      <?php echo Form::text('address',$facility->address,['class' => 'form-control', 'placeholder' => 'Direccion']); ?>

    </div>
  </div>
  <div class="form-row">
    <div class="col">
      <div class="form-check">
        <?php echo Form::checkbox('active', 'true', $facility->status, ['class' => 'form-check-input big-checkbox', 'type' => 'checkbox']); ?>

        <?php echo Form::label('active', 'Activa', ['class' => 'form-check-label', 'for' => 'active']); ?>

      </div>
    </div>
    <div class="col">
      <div class="float-right">
        <input type="submit" value="Guardar" class="btn btn-primary">
      </div>
    </div>
  </div>
<?php echo Form::close(); ?>

