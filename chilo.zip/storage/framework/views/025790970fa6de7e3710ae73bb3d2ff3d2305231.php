<?php echo Form::open(['route' => [$exclusive->url(),$exclusive->id],'method' => $exclusive->method(), 'class' => 'app-form']); ?>

<div class="form-row">
  <div class="col">
    <?php echo Form::label('id', 'Id Sistema'); ?>

    <?php echo Form::text('id', $exclusive->id,['class' => 'form-control', 'readonly' => 'true'] ); ?>

  </div>
  <div class="col">
    <?php echo Form::label('name', 'Nombre'); ?>

    <?php echo Form::text('name',$exclusive->name,['class' => 'form-control'] ); ?>

  </div>
  <div class="col">
    <?php echo Form::label('category', 'Tipo'); ?>

    <?php echo Form::select('category', $exclusive->exTypes(), $exclusive->category, ['class' => 'form-control']); ?>

  </div>
  <div class="col">
    <?php echo Form::label('status', 'Activa'); ?>

    <?php echo Form::checkbox('status', 'value', $exclusive->status, ['class' => 'displayBlock']); ?>

  </div>
</div>
  <div class="form-row">
    <div class="col">
      <?php echo Form::label('description', 'Detalle'); ?>

      <?php echo Form::text('description',$exclusive->description,['class' => 'form-control']); ?>

    </div>
  </div>
<div class="form-row">
  <div class="col">
    <?php echo Form::label('start', 'Vigencia Inicio'); ?>

    <?php echo Form::date('start', \Carbon\Carbon::now()); ?>

  </div>
  <div class="col">
    <?php echo Form::label('end', 'Vigencia Fin'); ?>

    <?php echo Form::date('end', \Carbon\Carbon::now()); ?>

  </div>
  <div class="col">
    <?php echo Form::label('amount', 'Valor'); ?>

    <?php echo Form::text('amount',$exclusive->amount,['class' => 'form-control']); ?>

  </div>
  <div class="col">
    <?php echo Form::label('amount_type', 'Tipo Valor'); ?>

    <?php echo Form::select('amount_type', $exclusive->exaTypes(), $exclusive->amount_type, ['class' => 'form-control']); ?>

  </div>
  <div class="col">
    <?php echo Form::label('availability', 'Disponibilidad'); ?>

    <?php echo Form::text('availability',$exclusive->availability,['class' => 'form-control']); ?>

  </div>
</div>
  <div class="float-right">
    <input type="submit" value="Guardar" class="btn btn-primary">
  </div>
<?php echo Form::close(); ?>

