<table class="table">
  <thead>
    <tr>
      <th scope="col">Asignar</th>
      <th scope="col">Detalle</th>
    </tr>
  </thead>
<?php $__currentLoopData = $poll->questions(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <tr>
    <td>
      <?php if(isset($poll->id)): ?>
        <?php
          $found = false;
        ?>
        <?php $__currentLoopData = $poll->getPollQuestions($poll->id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php if($value->question_id == $question->id): ?>
            <?php echo Form::checkbox('questions[]', $question->id, true); ?>

            <?php
              $found = true;
            ?>
          <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php if(!$found): ?>
          <?php echo Form::checkbox('questions[]', $question->id, false); ?>

        <?php endif; ?>
      <?php else: ?>
        <?php echo Form::checkbox('questions[]', $question->id, false); ?>

      <?php endif; ?>
    </td>
    <td><?php echo e($question->description); ?></td>
  </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
