<div id="loading-div-background">
  <div id="loading-div" class="ui-corner-all">
    <img style="height:100%;width:100%;" src=<?php echo e(asset('img/pw3.gif')); ?> alt="Procesando.."/>
  </div>
</div>
