<?php echo Form::open(['route' => [$question->url(),$question->id],'method' => $question->method(), 'class' => 'app-form']); ?>

<div class="form-row">
  <div class="col">
    <?php echo Form::label('description', 'Descripción'); ?>

    <?php echo Form::text('description',$question->description,['class' => 'form-control'] ); ?>

  </div>
</div>
  <div class="form-row">
    <div class="col">
      <?php echo Form::label('id', 'Id Sistema'); ?>

      <?php echo Form::text('id', $question->id,['class' => 'form-control', 'readonly' => 'true'] ); ?>

    </div>
    <div class="col">
      <?php echo Form::label('category', 'Categoria'); ?>

      <?php echo Form::select('category', $question->pqCategories(), $question->category, ['class' => 'form-control']); ?>

    </div>
    <div class="col">
      <?php echo Form::label('control', 'Tipo de control'); ?>

      <?php echo Form::select('control', $question->qcTypes(), $question->control, ['class' => 'form-control']); ?>

    </div>
  </div>
  <div class="form-row">
    <div class="col">
      <div class="form-check">
        <?php echo Form::checkbox('status', 'true', $question->status, ['class' => 'form-check-input big-checkbox', 'type' => 'checkbox']); ?>

        <?php echo Form::label('status', 'Activa', ['class' => 'form-check-label', 'for' => 'status']); ?>

      </div>
    </div>
    <div class="col">
      <div class="float-right">
        <input type="submit" value="Guardar" class="btn btn-primary">
      </div>
    </div>
  </div>
<?php echo Form::close(); ?>

