<?php echo Form::text('answer', '',['class' => 'form-control', 'placeholder' => 'Ingrese su respuesta', 'id' => 'answer'] ); ?>

<?php echo e(Form::hidden('vals[]', '', ['id' => 'openQ'])); ?>

