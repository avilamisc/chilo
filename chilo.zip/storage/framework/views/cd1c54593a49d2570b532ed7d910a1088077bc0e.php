<?php echo Form::open(['route' => [$poll->url(),$poll->id],'method' => $poll->method(), 'class' => 'app-form']); ?>

<div class="form-row">
  <div class="col-1">
    <?php echo Form::label('id', 'Id Sistema'); ?>

    <?php echo Form::text('id', $poll->id,['class' => 'form-control', 'readonly' => 'true'] ); ?>

  </div>
  <div class="col-4">
    <?php echo Form::label('name', 'Nombre'); ?>

    <?php echo Form::text('name',$poll->name,['class' => 'form-control'] ); ?>

  </div>
  <div class="col">
    <?php echo Form::label('poll_type', 'Categoria'); ?>

    <?php echo Form::select('poll_type', $poll->pCategories(), $poll->type, ['class' => 'form-control']); ?>

  </div>
  <div class="col">
      <?php echo Form::label('id_facility', 'Sucursal'); ?>

      <?php echo Form::select('id_facility', $poll->getFacilities(), $poll->id_facility, ['class' => 'form-control']); ?>

  </div>
</div>
<div class="form-row">
  <div class="col">
    <div class="form-check">
      <?php echo Form::label('status', 'Activa'); ?>

      <?php echo Form::checkbox('status', 'value', $poll->status, ['class' => 'displayBlock']); ?>

    </div>
  </div>
  <div class="col">
    <div class="float-right">
      <input type="submit" value="Guardar" class="btn btn-primary">
    </div>
  </div>
</div>
<div class="form-row">
  <div class="col">
    <?php echo $__env->make('polls.questions', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  </div>
</div>


<?php echo Form::close(); ?>

