<?php echo Form::open(['route' => [$table->url(),$table->id],'method' => $table->method(), 'class' => 'app-form']); ?>

  <div class="form-row">
    <div class="col">
      <?php echo Form::label('id', 'Id Sistema'); ?>

      <?php echo Form::text('id', $table->id,['class' => 'form-control', 'readonly' => 'true'] ); ?>

    </div>
    <div class="col">
      <?php echo Form::label('table_number', '# Mesa'); ?>

      <?php echo Form::text('table_number', $table->table_number,['class' => 'form-control', 'placeholder' => '# Mesa'] ); ?>

    </div>
    <div class="col">
      <?php echo Form::label('capacity', '# Asientos'); ?>

      <?php echo Form::number('capacity', $table->capacity, ['class' => 'form-control']); ?>

    </div>
    <div class="col">
      <?php echo Form::label('id_facility', 'Id Sucursal'); ?>

      <?php echo Form::select('id_facility', $table->getFacilities(), $table->id_facility, ['class' => 'form-control']); ?>

    </div>
    <div class="col">
      <?php echo Form::label('location', 'Ubicacion en Sucursal'); ?>

      <?php echo Form::text('location',$table->location,['class' => 'form-control', 'placeholder' => 'Ubicacion'] ); ?>

    </div>
  </div>
  <div class="form-row">
    <div class="col">
      <div class="form-check">
        <?php echo Form::checkbox('status', 'true', $table->status, ['class' => 'form-check-input big-checkbox', 'type' => 'checkbox']); ?>

        <?php echo Form::label('status', 'Activa', ['class' => 'form-check-label', 'for' => 'status']); ?>

      </div>
      </div>
      <div class="col">
        <div class="float-right">
          <input type="submit" value="Guardar" class="btn btn-primary">
        </div>
      </div>
  </div>
<?php echo Form::close(); ?>


<div id="loading-div-background">
  <div id="loading-div" class="ui-corner-all">
    <img style="height:100%;width:100%;" src=<?php echo e(asset('img/pw3.gif')); ?> alt="Procesando.."/>
    <!--br>PROCESANDO. POR FAVOR ESPERE... -->
  </div>
</div>
