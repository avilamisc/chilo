<?php $__env->startSection('content'); ?>
<div class="container">
  <div class="card padding">
    <header>
      <h4>Editar mesa</h4>
    </header>

    <div class="card-body">
      <?php echo $__env->make('tables.error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <?php echo $__env->make('tables.form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
  </div>
</div>
<?php echo $__env->make('tables.pw', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>