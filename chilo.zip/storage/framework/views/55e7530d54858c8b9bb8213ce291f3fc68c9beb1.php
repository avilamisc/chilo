<?php echo Form::open(['route' => [$user->url(),$user->id],'method' => $user->method(), 'class' => 'app-form']); ?>


  <div class="form-row">
    <div class="col-1">
      <div class="">
        <?php echo Form::label('id', 'Id Sistema'); ?>

        <?php echo Form::text('id', $user->id,['class' => 'form-control', 'readonly' => 'true'] ); ?>

      </div>
    </div>
    <div class="col">
      <div class="">
        <?php echo Form::label('name', 'Nombre'); ?>

        <?php echo Form::text('name', $user->name,['class' => 'form-control'] ); ?>

      </div>
    </div>
    <div class="col">
      <div class="">
        <?php echo Form::label('email', 'Correo Electronico'); ?>

        <?php echo Form::text('email', $user->email,['class' => 'form-control'] ); ?>

      </div>
    </div>
  </div>
  <hr>
  <div class="row">
    <div class="col">
      <h3>Lista de Roles</h3>
      <div class="form-group">

      </div>
      <ul class="list-unstyled">
        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php
          $checked = false;

          foreach ($user->getRoles() as $asignedRole) {          
            if ($role->id == $asignedRole) {
                $checked = true;
                continue;
            }
          }

          ?>
          <li>
            <label>
              <?php echo e(Form::checkbox('roles[]', $role->id, $checked)); ?>

              <?php echo e($role->name); ?>

              <em>(<?php echo e($role->description); ?>)</em>
            </label>
          </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      </ul>
    </div>
  </div>
<div class="form-row">
  <div class="col">
    <div class="float-right">
      <input type="submit" value="Guardar" class="btn btn-primary">
    </div>
  </div>
</div>
<?php echo Form::close(); ?>

