<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>{{ config('app.name', 'Laravel') }}</title>

    <!-- Scripts -->
    <script src="{{ asset('js/app.js') }}" defer></script>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <!-- Fonts -->
    <link rel="dns-prefetch" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet" type="text/css">

    <!-- Styles -->
    <link href="{{ asset('css/app.css') }}" rel="stylesheet">

    <!-- Icons -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.2.0/css/all.css" integrity="sha384-hWVjflwFxL6sNzntih27bfxkr27PmbbK/iSvJ+a4+0owXq79v+lsFkW54bOGbiDQ" crossorigin="anonymous">

</head>
<body>
    <div id="app">
        <nav class="navbar navbar-expand-md navbar-light navbar-laravel">
            <div class="container">
                <a class="navbar-brand" href="{{ url('/') }}">
                    {{ config('app.name', 'Laravel') }}
                </a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="{{ __('Toggle navigation') }}">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <!-- Left Side Of Navbar -->
                    <ul class="navbar-nav mr-auto">

                    </ul>

                    <!-- Right Side Of Navbar -->
                    <ul class="navbar-nav ml-auto">
                        <!-- Authentication Links -->
                        @guest
                            <li class="nav-item">
                                <a class="nav-link" href="{{ route('login') }}">{{ __('Login') }}</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="{{ route('register') }}">{{ __('Register') }}</a>
                            </li>
                        @else
                          <li id="home" class="nav-item">
                              <a class="nav-link" href="/home">Inicio</a>
                          </li>
                          @can ('sucursales.index')
                          <li id="facilities" class="nav-item">
                              <a class="nav-link" href="/sucursales">Sucursales</a>
                          </li>
                          @endcan
                          @can ('mesas.index')
                            <li id="tables" class="nav-item">
                                <a class="nav-link" href="/mesas">Mesas</a>
                            </li>
                          @endcan
                          @can ('meseros.index')
                            <li id="waiters" class="nav-item">
                                <a class="nav-link" href="/meseros">Meseros</a>
                            </li>
                          @endcan
                          @can ('encuestas.index')
                            <li id="polls" class="nav-item">
                                <a class="nav-link" href="/encuestas">Encuestas</a>
                            </li>
                          @endcan
                          @can ('preguntas.index')
                            <li id="questions" class="nav-item">
                                <a class="nav-link" href="/preguntas">Preguntas</a>
                            </li>
                          @endcan
                          @can ('exclusivos.index')
                            <li id="exclusives" class="nav-item">
                                <a class="nav-link" href="/exclusivos">Promo/Desctos</a>
                            </li>
                          @endcan
                          @can ('.index')
                            <li id="usuarios" class="nav-item">
                                <a class="nav-link" href="/usuarios">Usuarios</a>
                            </li>
                          @endcan
                          @can ('roles.index')
                            <li id="roles" class="nav-item">
                                <a class="nav-link" href="/roles">Roles</a>
                            </li>
                          @endcan

                          <li class="nav-item dropdown">
                              <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                  {{ Auth::user()->name }} <span class="caret"></span>
                              </a>

                              <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                  <a class="dropdown-item" href="{{ route('logout') }}"
                                     onclick="event.preventDefault();
                                                   document.getElementById('logout-form').submit();">
                                      {{ __('Logout') }}
                                  </a>

                                  <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                                      @csrf
                                  </form>
                              </div>
                          </li>
                        @endguest
                    </ul>
                </div>
            </div>
        </nav>
        <main class="py-4">
          @if (session('info'))
            <div class="container">
              <div class="row">
                <div class="col-md-8 col-md-offset-2">
                  <div class="alert alert-success">
                    <button type="button" class="close" data-dismiss="alert">
                        &times;
                    </button>
                      {{ session('info') }}
                  </div>
                </div>
              </div>
            </div>
          @endif
            @yield('content')
        </main>
    </div>
    @yield('scripts')
</body>
</html>
