Hola <strong>{{ $name }}</strong>,

<p>Descripcion {{ $body }}</p>
