<div class="">
  <span id="s1" class="far fa-star fa-2x pointerElement"></span>
  <span id="s2" class="far fa-star fa-2x pointerElement"></span>
  <span id="s3" class="far fa-star fa-2x pointerElement"></span>
  <span id="s4" class="far fa-star fa-2x pointerElement"></span>
  <span id="s5" class="far fa-star fa-2x pointerElement"></span>
</div>
{{ Form::hidden('vals[]', '', ['id' => 'openRa']) }}
