<div class="">
  <div id="edex" class="d-inline px-2">
    <span id="eiex" class="far fa-grin-stars fa-2x pointerElement"></span>
    <span id="etb" class="ml-1 pointerElement">Excelente</span>
  </div>
  <div id="edmb" class="d-inline px-2">
    <span id="eimb" class="far fa-grin fa-2x pointerElement"></span>
    <span id="etb" class="ml-1 pointerElement">Muy bueno</span>
  </div>
  <div id="edb" class="d-inline px-2">
    <span id="eib" class="far fa-smile fa-2x pointerElement"></span>
    <span id="etb" class="ml-1 pointerElement">Bueno</span>
  </div>
  <div id="edr" class="d-inline px-2">
    <span id="eir" class="far fa-frown fa-2x pointerElement"></span>
    <span id="etr" class="ml-1 pointerElement">Regular</span>
  </div>
</div>
{{ Form::hidden('vals[]', '', ['id' => 'openEm']) }}
