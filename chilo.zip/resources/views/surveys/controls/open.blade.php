{!! Form::text('answer', '',['class' => 'form-control', 'placeholder' => 'Ingrese su respuesta', 'id' => 'answer'] ) !!}
{{ Form::hidden('vals[]', '', ['id' => 'openQ']) }}
