<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class QControlType extends Model
{
    //
    public $fillable = ['name'];
}
