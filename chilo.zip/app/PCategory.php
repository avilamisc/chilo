<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PCategory extends Model
{
    //
    public $fillable = ['name'];
}
