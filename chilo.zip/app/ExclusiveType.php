<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ExclusiveType extends Model
{
    //
    public $fillable = ['name'];
}
