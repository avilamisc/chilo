<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PQuestion extends Model
{
    //
    public $fillable = ['poll_id', 'question_id'];
}
